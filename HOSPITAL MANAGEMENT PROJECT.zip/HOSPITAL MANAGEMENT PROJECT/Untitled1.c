#include <stdio.h>
struct marks
{
    int a,b;
};
int main()
{
    typedef struct marks *ptr;
    scanf("%d",ptr->a);
    scanf("%d",ptr->b);
    printf("%d\n%d",m.a,m.b);
}
